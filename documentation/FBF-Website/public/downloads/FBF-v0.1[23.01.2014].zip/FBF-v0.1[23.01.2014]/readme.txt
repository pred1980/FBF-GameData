This package contains three versions of "Forsaken Bastion's Fall".

Date: 23.01.2014
Version: 0.1 beta

The "Download" is for self hosting.
The "All Pick and All Random" is for hosting by using a bot.

***HAVE FUN***

Your FBF Team

NOTE: Report any bugs to --> http://forsaken-bastions-fall.com/bugs